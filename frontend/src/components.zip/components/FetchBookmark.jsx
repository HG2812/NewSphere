// import React, { useState, useEffect } from 'react';
// import Card  from './EverythingCard ';

// const FetchBookmark = () => {
//   const [bookmarks, setBookmarks] = useState([]);

//   useEffect(() => {
//     const fetchBookmarks = async () => {
//       try {
//         const response = await fetch('http://localhost:3000/bookmarks/save');
//         setBookmarks(response.data);
//       } catch (error) {
//         console.error('Error fetching bookmarks:', error);
//       }
//     };

//     fetchBookmarks();
//   }, []);

//   return (
//     <div>
//       {bookmarks.map((bookmark) => (
//         <Card key={bookmark._id} ref={React.createRef()} {...bookmark} />
//       ))}
//     </div>
//   );
// };

// export default FetchBookmark;

import { useState, useEffect } from 'react';
import Card from './EverythingCard';

const FetchBookmark = () => {
  const [bookmarks, setBookmarks] = useState([]);

  useEffect(() => {
    const fetchBookmarks = async () => {
      try {
        const response = await fetch('http://localhost:3000/bookmarks');
        const data = await response.json();
        setBookmarks(data);
      } catch (error) {
        console.error('Error fetching bookmarks:', error);
      }
    };

    fetchBookmarks();
  }, []);

  return (
    <div>
      {bookmarks.map((bookmark) => (
        <Card key={bookmark._id} {...bookmark} />
      ))}
    </div>
  );
};

export default FetchBookmark;

